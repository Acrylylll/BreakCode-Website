Ⅰ================Ⅰ
Ⅰ     README     Ⅰ
Ⅰ================Ⅰ

This website was made ONLY FOR FUN and is NOT used to insult anyone.

You can freely copy unicodes from the BreakCode website.

Credits:
Acrylylll, reddit, microsoft, google, compart.

Special thanks:
Puneet, reddit, compart.